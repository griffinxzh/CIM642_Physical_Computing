#Keyboard Piano

Clone or download the project, start it under a server environment, open index.html. That is to say, don't open it as "file://", because it won't work that way.

You can use keyboard to play the piano now. Use A S D F J K L ; (8keys to do so). They represent a3 b3 c3 d3 e3 f3 g3 ha4 sounds in music theory. Choosing these 8 keys is for the reason that they are the most natural keys when a typer place his fingers on the keyboard.

When you press A, you can see that a piano key on the screen is pressed down and moved up to its original place. When you press S, similar effect takes place and you get a higher sound.

Here is music score for Twinkle Twinkle Little Star.

AAJJKKJ FFDDSSA
JJFFDDS JJFFDDS
AAJJKKJ FFDDSSA

You can also convert other song's score to what can be played in this keyboard piano if you have basic knowledge of music theory.

Please enjoy it!
